import java.util.TreeSet;

public class SortedPerson {
	public static void main(String[] args) {
	//	PersonComparator pc=new PersonComparator();  //using comparator;dont implement comparable to person
	//	TreeSet<Person> persons = new TreeSet<>(pc);
		TreeSet<Person> persons = new TreeSet<>(); //sortedSet
		
		persons.add(new Person("Polo",21));
		persons.add(new Person("Lili",18));
		persons.add(new Person("Mili",20));
		
		for (Person person : persons) {
			System.out.println(person.getName()+"  "+person.getAge());
			
		}
		
	}

}
