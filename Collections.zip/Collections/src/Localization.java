import java.util.Locale;
import java.util.ResourceBundle;

public class Localization {

	public static void main(String[] args) {
		Locale hi=new Locale("hi");
		ResourceBundle bundle=ResourceBundle.getBundle("greeting",Locale.FRANCE);
		
		ResourceBundle bundle1=ResourceBundle.getBundle("greeting",hi);
		System.out.println(bundle1.getString("message"));
		System.out.println(bundle1.getString("greetings"));

	}

}
