import static java.util.Calendar.*;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
public class TimeZoneDemo {

	public static void main(String[] args) {
	/*String[] zones=TimeZone.getAvailableIDs();
	for (String zone : zones) {
		System.out.println(zone);
	}
	System.out.println(zones.length);*/
		TimeZone zone=TimeZone.getTimeZone("EST");
		Calendar cal=getInstance(zone);
		System.out.println(cal.get(HOUR_OF_DAY));
		System.out.println(cal.get(MINUTE));
		Date now=new Date();
		System.out.println(now);

	}

}
